import pandas as pd
import numpy as np
import re

try: 
    name = input("Enter a class file to grade (i.e. class1 for class1.txt): ")
    filename ='Data_Files/' + name + '.txt'
    df=pd.read_csv(filename, header=None, sep='\t')
    # print(file1.closed)
    file_out = name + '_grades.txt'
except IOError:
    print("File cannot be found")
else:
    print("Successfully opened " + name + '.txt')


valid = 0
invalid = 0
l = df.size
new_filelist = []
for i in range(0, l):
    a = [df.iloc[i,0].split(",")]
    filelist = df.iloc[i,0]
    regex='(N[0-9]{8})'
    data=re.findall(regex, df.iloc[i,0])
    x = filelist.split(",")
    new_filelist.append(x)
# print(new_filelist[0])
valid = 0
invalid = 0
for i in range(0,l):
    regex='(N[0-9]{8})'
    x=re.findall(regex, new_filelist[i][0])
    s = len(new_filelist[i])
    if (s == 26) :
        if (len(x) == 1) and (len(x[0]) == 9):
            valid = valid + 1
        else:
            if len(x) == 0:
                print("Invalid line of data: N# is invalid\n",new_filelist[i] )
    else:
        print("Invalid line of data: does not contain exactly 26 values:\n",new_filelist[i])
        invalid = invalid +1
if invalid == 0:
    print("No errors found!")

print("*** 2.1. Báo cáo tổng số dòng dữ liệu được lưu trữ trong tệp. ***")
print("Total number of lines in the text file are: ",l)
print("*** ANALYZING ***")
print("Total valid lines of data: ", valid )
print("Total invalid lines of data: ", l - valid )






