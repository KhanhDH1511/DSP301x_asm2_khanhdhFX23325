# Lấy các thư việc sử dụng
import re
from collections import Counter

# Task 1: 
# Sử dụng try/except để người dùng nhập tên 1 tệp và truy cập đọc
try: 
    name = input("Enter a class file to grade (i.e. class1 for class1.txt): ")
    filename ='Data_Files/' + name + '.txt'
    with open (filename , "r") as file1:
        File = file1.read()
    print(file1.closed)

    file_out = name + '_grades.txt' # Sử dụng cho Task 4
except IOError:
    print("File cannot be found")
else:
    print("Successfully opened " + name + '.txt')

# Task 2:

#  2.1. Báo cáo tổng số dòng dữ liệu được lưu trữ trong tệp.
filelist = File.split('\n')    
# print("*** 2.1. Báo cáo tổng số dòng dữ liệu được lưu trữ trong tệp. ***")
l = len(filelist)
print("Total number of lines in the text file are: ",l)

#  2.2. Báo cáo tổng số dòng dữ liệu không hợp lệ trong tệp.
print("*** ANALYZING ***")

valid = 0
invalid = 0
# Sử dụng vòng lặp for để kiểm tra điều kiện của đáp án có đúng hay không
for i in range(0,l):
    regex='(N[0-9]{8})'
    data=re.findall(regex, filelist[i])
    x = filelist[i].split(",")
    if (len(x) == 26) :
        if len(data)==1 and len(data[0]) == 9:
            valid = valid + 1
        else:
            if len(data)==0:
                print("Invalid line of data: N# is invalid\n",filelist[i] )
    else:
        print("Invalid line of data: does not contain exactly 26 values:\n",filelist[i])
        invalid = invalid +1
if invalid == 0:
    print("No errors found!")

print("*** REPORT ***")
print("Total valid lines of data: ", valid )
print("Total invalid lines of data: ", l - valid )

# Task 3: 

kq = 0
skip = []     # List các câu hỏi bị bỏ qua 
wr = []       # List các câu hỏi bị sai 
kq_list = []  # List kết quả
answer_key= "B,A,D,D,C,B,D,A,C,C,D,B,A,B,A,C,B,D,A,C,A,A,B,D,D"
Ans_key_list = (answer_key.split(","))

# Sử dụng vòng lặp for để kiểm tra điều kiện như ở task 2
for j in range(0,l):
    answer_regex = 'N[0-9]{8},(.+)'
    answer=re.findall(answer_regex, filelist[j])

    # Sử dụng lệnh if: nếu dòng nào không bằng rỗng thì chuyển thành 1 list các đáp án
    if (len(answer) == 1):
        Ans = answer[0].split(",")

    # Sử dụng lệnh if và for để so sánh đáp án lấy được từ data và đáp án chính xác
    if(len(Ans) == 25) and (len(answer) == 1):
        # print (len(answer),(Ans))
        for a in range(0, len(Ans_key_list)):
            # print(Ans[a])
            if (Ans[a] == Ans_key_list[a]) and (Ans[a] != ""): # So sánh nếu đáp án đúng VÀ không bị bỏ qua
                kq = kq + 4
            elif Ans[a] != Ans_key_list[a] and (Ans[a] != ""): # So sánh nếu đáp án sai VÀ không bị bỏ qua
                kq = kq -1
                wr.append(a) # Thêm đáp án bị sai vào list wr = [] 
            else: # Còn lại là các câu hỏi bị bỏ qua
                kq = kq 
                skip.append(a) # Thêm các câu hỏi bị bỏ qua vào list skip = []
        kq_list.append(kq) # Thêm các kết quả vào list kq_list = []
    kq = 0

# 3.1 -> 3.5: In các kết quả theo yêu cầu đề bài
max = max(kq_list)
min = min(kq_list)
mean = sum(kq_list)/len(kq_list)
print("Mean (average) score: ", round(mean,3))
print("Highest score:", max )
print("Lowest score:", min )
print("Range of scores:", max - min )

# 3.6: Tìm giá trị trung vị theo yêu cầu đề bài
kq_sorted = sorted(kq_list)
#print(kq_sorted)
k = len(kq_sorted)
if k % 2 == 0: # Nếu số kết quả của học sinh là số chẵn 
    k_up = int(k/2 +1)
    k_down = int(k/2 -1)
    Median_score = kq_sorted[k_down:k_up]
    print("Median_score:", round(sum(Median_score)/len(Median_score),3))
else: # Số kết quả của học sinh là số lẻ
    k_mid = int((k/2) + 1)
    print("Median_score:", kq_sorted[k_mid])

# 3.7: Tìm các câu hỏi bị bỏ qua nhiều nhất
# Tạo hàm tìm các câu hỏi bị bỏ qua nhiều nhất
skip_answer = []
def findMajority_skip(arr):
    lst = [x + 1 for x in arr]
    counter_lst = Counter(lst)
    most_skip_elements = counter_lst.most_common() # Trả về 1 list ('các câu hỏi bị bỏ qua', 'số lần bỏ qua').
    # Đặc biệt 'số lần bỏ qua' được sắp xếp từ lớn đến bé nên ta dễ dàng tìm số lần câu hỏi bị bỏ qua nhiều nhất
    skip_maxCount = most_skip_elements[0][1]
    ##  print(most_common_elements)
    ##  print("*Skip max:",skip_maxCount)
    len_skip = int(len(most_skip_elements))
    # Tính tỉ lệ bị bỏ qua
    rate = round((skip_maxCount/valid),2)
    # print(rate)
    for s in range(0,len_skip):
        # Sử dụng lệnh if: nếu số câu hỏi bị bỏ qua bằng số câu hỏi bị bỏ qua nhiều nhất thì thêm nó và list skip_answer = []
        if (most_skip_elements[s][1]) == skip_maxCount:
            skip_answer.append(most_skip_elements[s])
            skip_answer[s] = skip_answer[s] + (rate,)
    print("Question that most people skip:",skip_answer)
findMajority_skip(skip)

# 3.8: Tìm các câu hỏi bị sai nhiều nhất
# Tạo hàm tìm các câu hỏi bị sai nhiều nhất 
wr_answer = []
def findMajority_wr(arr):
    lst = [x + 1 for x in arr]
    counter_lst = Counter(lst)
    most_wr_elements = counter_lst.most_common() # Hàm trả về 1 list ('các câu hỏi bị sai', 'số lần sai').
    # Đặc biệt "số lần sai" được sắp xếp từ lớn đến bé nên ta dễ dàng tìm số lần sai nhiều nhất
    wr_maxCount = most_wr_elements[0][1]
    ## print(most_common_elements)
    ## print("*Wrong max:",wr_maxCount)
    len_wr = int(len(most_wr_elements))
    # Tính tỉ lệ bị sai
    rate = round((wr_maxCount/valid),2)
    # print(rate)
    for s in range(0,len_wr):
        # Sử dụng lệnh if: nếu số câu hỏi sai bằng số câu hỏi sai nhiều nhất thì thêm nó và list wr_answer = []
        if (most_wr_elements[s][1]) == wr_maxCount:
            wr_answer.append(most_wr_elements[s])
            wr_answer[s] = wr_answer[s] + (rate,)
    print("Question that most people answer incorrectly:",wr_answer)
findMajority_wr(wr)

# Task 4
data_id = []
# Mở file mode Write
with open(file_out, "w") as f_out:
    # Sử dụng vòng lặp for kiểm tra điều kiện như ở Task 2
    for t in range(0,l):
        answer_regex1 = 'N[0-9]{8},(.+)'
        answer1=re.findall(answer_regex1, filelist[t])
        if (len(answer1) == 1):
            Ans1 = answer1[0].split(",")
        regex='(N[0-9]{8})'
        data=re.findall(regex, filelist[t])
        len_data = len(data)
        # Sử dụng if để so sánh điều kiện so với đề bài, nếu đúng thì sẽ thêm vào List data_id = []
        if(len(Ans1) == 25) and (len_data == 1):
            data_id.append(data)
    # Sử dụng vòng lặp for để ghi vào 1 file mới với các phần tử ID, Kết quả
    for d in range(0,len(data_id)):
        f_out.write("{}, {}\n".format((data_id[d][0]), kq_list[d]))
        # print(data_id[d][0],",",kq_list[d])

# Task 5 ở file Task5.py: Chỉ làm được Task 1, Task2: 2.1, 2.2









